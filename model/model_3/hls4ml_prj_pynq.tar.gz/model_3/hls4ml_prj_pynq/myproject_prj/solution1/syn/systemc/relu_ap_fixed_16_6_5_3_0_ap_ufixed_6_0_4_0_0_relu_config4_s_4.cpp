#include "relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_43_fu_2582_p4() {
    trunc_ln708_43_fu_2582_p4 = data_16_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_44_fu_2720_p4() {
    trunc_ln708_44_fu_2720_p4 = data_17_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_45_fu_2858_p4() {
    trunc_ln708_45_fu_2858_p4 = data_18_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_46_fu_2996_p4() {
    trunc_ln708_46_fu_2996_p4 = data_19_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_47_fu_3134_p4() {
    trunc_ln708_47_fu_3134_p4 = data_20_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_48_fu_3272_p4() {
    trunc_ln708_48_fu_3272_p4 = data_21_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_49_fu_3410_p4() {
    trunc_ln708_49_fu_3410_p4 = data_22_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_50_fu_3548_p4() {
    trunc_ln708_50_fu_3548_p4 = data_23_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_51_fu_3686_p4() {
    trunc_ln708_51_fu_3686_p4 = data_24_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_52_fu_3824_p4() {
    trunc_ln708_52_fu_3824_p4 = data_25_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_53_fu_3962_p4() {
    trunc_ln708_53_fu_3962_p4 = data_26_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_54_fu_4100_p4() {
    trunc_ln708_54_fu_4100_p4 = data_27_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_55_fu_4238_p4() {
    trunc_ln708_55_fu_4238_p4 = data_28_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_56_fu_4376_p4() {
    trunc_ln708_56_fu_4376_p4 = data_29_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_57_fu_4514_p4() {
    trunc_ln708_57_fu_4514_p4 = data_30_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_58_fu_4652_p4() {
    trunc_ln708_58_fu_4652_p4 = data_31_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_59_fu_4790_p4() {
    trunc_ln708_59_fu_4790_p4 = data_32_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_60_fu_4928_p4() {
    trunc_ln708_60_fu_4928_p4 = data_33_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_61_fu_5066_p4() {
    trunc_ln708_61_fu_5066_p4 = data_35_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_62_fu_5204_p4() {
    trunc_ln708_62_fu_5204_p4 = data_36_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_63_fu_5342_p4() {
    trunc_ln708_63_fu_5342_p4 = data_37_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_64_fu_5480_p4() {
    trunc_ln708_64_fu_5480_p4 = data_38_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_65_fu_5618_p4() {
    trunc_ln708_65_fu_5618_p4 = data_39_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_66_fu_5756_p4() {
    trunc_ln708_66_fu_5756_p4 = data_40_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_67_fu_5894_p4() {
    trunc_ln708_67_fu_5894_p4 = data_42_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_68_fu_6032_p4() {
    trunc_ln708_68_fu_6032_p4 = data_43_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_69_fu_6170_p4() {
    trunc_ln708_69_fu_6170_p4 = data_44_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_70_fu_6308_p4() {
    trunc_ln708_70_fu_6308_p4 = data_45_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_71_fu_6446_p4() {
    trunc_ln708_71_fu_6446_p4 = data_46_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_72_fu_6584_p4() {
    trunc_ln708_72_fu_6584_p4 = data_48_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_73_fu_6722_p4() {
    trunc_ln708_73_fu_6722_p4 = data_49_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_74_fu_6860_p4() {
    trunc_ln708_74_fu_6860_p4 = data_50_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_75_fu_6998_p4() {
    trunc_ln708_75_fu_6998_p4 = data_51_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_76_fu_7136_p4() {
    trunc_ln708_76_fu_7136_p4 = data_52_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_77_fu_7274_p4() {
    trunc_ln708_77_fu_7274_p4 = data_53_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_78_fu_7412_p4() {
    trunc_ln708_78_fu_7412_p4 = data_54_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_79_fu_7550_p4() {
    trunc_ln708_79_fu_7550_p4 = data_55_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_80_fu_7688_p4() {
    trunc_ln708_80_fu_7688_p4 = data_57_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_81_fu_7826_p4() {
    trunc_ln708_81_fu_7826_p4 = data_58_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_82_fu_7964_p4() {
    trunc_ln708_82_fu_7964_p4 = data_59_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_83_fu_8102_p4() {
    trunc_ln708_83_fu_8102_p4 = data_60_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_84_fu_8240_p4() {
    trunc_ln708_84_fu_8240_p4 = data_61_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_85_fu_8378_p4() {
    trunc_ln708_85_fu_8378_p4 = data_63_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_s_fu_650_p4() {
    trunc_ln708_s_fu_650_p4 = data_1_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_31_fu_668_p1() {
    trunc_ln718_31_fu_668_p1 = data_1_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_32_fu_806_p1() {
    trunc_ln718_32_fu_806_p1 = data_2_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_33_fu_944_p1() {
    trunc_ln718_33_fu_944_p1 = data_3_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_34_fu_1082_p1() {
    trunc_ln718_34_fu_1082_p1 = data_4_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_35_fu_1220_p1() {
    trunc_ln718_35_fu_1220_p1 = data_5_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_36_fu_1358_p1() {
    trunc_ln718_36_fu_1358_p1 = data_6_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_37_fu_1496_p1() {
    trunc_ln718_37_fu_1496_p1 = data_7_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_38_fu_1634_p1() {
    trunc_ln718_38_fu_1634_p1 = data_8_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_39_fu_1772_p1() {
    trunc_ln718_39_fu_1772_p1 = data_9_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_40_fu_1910_p1() {
    trunc_ln718_40_fu_1910_p1 = data_10_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_41_fu_2048_p1() {
    trunc_ln718_41_fu_2048_p1 = data_12_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_42_fu_2186_p1() {
    trunc_ln718_42_fu_2186_p1 = data_13_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_43_fu_2324_p1() {
    trunc_ln718_43_fu_2324_p1 = data_14_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_44_fu_2462_p1() {
    trunc_ln718_44_fu_2462_p1 = data_15_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_45_fu_2600_p1() {
    trunc_ln718_45_fu_2600_p1 = data_16_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_46_fu_2738_p1() {
    trunc_ln718_46_fu_2738_p1 = data_17_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_47_fu_2876_p1() {
    trunc_ln718_47_fu_2876_p1 = data_18_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_48_fu_3014_p1() {
    trunc_ln718_48_fu_3014_p1 = data_19_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_49_fu_3152_p1() {
    trunc_ln718_49_fu_3152_p1 = data_20_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_50_fu_3290_p1() {
    trunc_ln718_50_fu_3290_p1 = data_21_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_51_fu_3428_p1() {
    trunc_ln718_51_fu_3428_p1 = data_22_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_52_fu_3566_p1() {
    trunc_ln718_52_fu_3566_p1 = data_23_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_53_fu_3704_p1() {
    trunc_ln718_53_fu_3704_p1 = data_24_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_54_fu_3842_p1() {
    trunc_ln718_54_fu_3842_p1 = data_25_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_55_fu_3980_p1() {
    trunc_ln718_55_fu_3980_p1 = data_26_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_56_fu_4118_p1() {
    trunc_ln718_56_fu_4118_p1 = data_27_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_57_fu_4256_p1() {
    trunc_ln718_57_fu_4256_p1 = data_28_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_58_fu_4394_p1() {
    trunc_ln718_58_fu_4394_p1 = data_29_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_59_fu_4532_p1() {
    trunc_ln718_59_fu_4532_p1 = data_30_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_60_fu_4670_p1() {
    trunc_ln718_60_fu_4670_p1 = data_31_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_61_fu_4808_p1() {
    trunc_ln718_61_fu_4808_p1 = data_32_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_62_fu_4946_p1() {
    trunc_ln718_62_fu_4946_p1 = data_33_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_63_fu_5084_p1() {
    trunc_ln718_63_fu_5084_p1 = data_35_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_64_fu_5222_p1() {
    trunc_ln718_64_fu_5222_p1 = data_36_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_65_fu_5360_p1() {
    trunc_ln718_65_fu_5360_p1 = data_37_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_66_fu_5498_p1() {
    trunc_ln718_66_fu_5498_p1 = data_38_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_67_fu_5636_p1() {
    trunc_ln718_67_fu_5636_p1 = data_39_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_68_fu_5774_p1() {
    trunc_ln718_68_fu_5774_p1 = data_40_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_69_fu_5912_p1() {
    trunc_ln718_69_fu_5912_p1 = data_42_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_70_fu_6050_p1() {
    trunc_ln718_70_fu_6050_p1 = data_43_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_71_fu_6188_p1() {
    trunc_ln718_71_fu_6188_p1 = data_44_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_72_fu_6326_p1() {
    trunc_ln718_72_fu_6326_p1 = data_45_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_73_fu_6464_p1() {
    trunc_ln718_73_fu_6464_p1 = data_46_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_74_fu_6602_p1() {
    trunc_ln718_74_fu_6602_p1 = data_48_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_75_fu_6740_p1() {
    trunc_ln718_75_fu_6740_p1 = data_49_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_76_fu_6878_p1() {
    trunc_ln718_76_fu_6878_p1 = data_50_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_77_fu_7016_p1() {
    trunc_ln718_77_fu_7016_p1 = data_51_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_78_fu_7154_p1() {
    trunc_ln718_78_fu_7154_p1 = data_52_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_79_fu_7292_p1() {
    trunc_ln718_79_fu_7292_p1 = data_53_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_80_fu_7430_p1() {
    trunc_ln718_80_fu_7430_p1 = data_54_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_81_fu_7568_p1() {
    trunc_ln718_81_fu_7568_p1 = data_55_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_82_fu_7706_p1() {
    trunc_ln718_82_fu_7706_p1 = data_57_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_83_fu_7844_p1() {
    trunc_ln718_83_fu_7844_p1 = data_58_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_84_fu_7982_p1() {
    trunc_ln718_84_fu_7982_p1 = data_59_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_85_fu_8120_p1() {
    trunc_ln718_85_fu_8120_p1 = data_60_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_86_fu_8258_p1() {
    trunc_ln718_86_fu_8258_p1 = data_61_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_87_fu_8396_p1() {
    trunc_ln718_87_fu_8396_p1 = data_63_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_fu_530_p1() {
    trunc_ln718_fu_530_p1 = data_0_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln_fu_512_p4() {
    trunc_ln_fu_512_p4 = data_0_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_31_fu_724_p2() {
    xor_ln416_31_fu_724_p2 = (tmp_144_fu_716_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_32_fu_862_p2() {
    xor_ln416_32_fu_862_p2 = (tmp_148_fu_854_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_33_fu_1000_p2() {
    xor_ln416_33_fu_1000_p2 = (tmp_152_fu_992_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_34_fu_1138_p2() {
    xor_ln416_34_fu_1138_p2 = (tmp_156_fu_1130_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_35_fu_1276_p2() {
    xor_ln416_35_fu_1276_p2 = (tmp_160_fu_1268_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_36_fu_1414_p2() {
    xor_ln416_36_fu_1414_p2 = (tmp_164_fu_1406_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_37_fu_1552_p2() {
    xor_ln416_37_fu_1552_p2 = (tmp_168_fu_1544_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_38_fu_1690_p2() {
    xor_ln416_38_fu_1690_p2 = (tmp_172_fu_1682_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_39_fu_1828_p2() {
    xor_ln416_39_fu_1828_p2 = (tmp_176_fu_1820_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_40_fu_1966_p2() {
    xor_ln416_40_fu_1966_p2 = (tmp_180_fu_1958_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_41_fu_2104_p2() {
    xor_ln416_41_fu_2104_p2 = (tmp_184_fu_2096_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_42_fu_2242_p2() {
    xor_ln416_42_fu_2242_p2 = (tmp_188_fu_2234_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_43_fu_2380_p2() {
    xor_ln416_43_fu_2380_p2 = (tmp_192_fu_2372_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_44_fu_2518_p2() {
    xor_ln416_44_fu_2518_p2 = (tmp_196_fu_2510_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_45_fu_2656_p2() {
    xor_ln416_45_fu_2656_p2 = (tmp_200_fu_2648_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_46_fu_2794_p2() {
    xor_ln416_46_fu_2794_p2 = (tmp_204_fu_2786_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_47_fu_2932_p2() {
    xor_ln416_47_fu_2932_p2 = (tmp_208_fu_2924_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_48_fu_3070_p2() {
    xor_ln416_48_fu_3070_p2 = (tmp_212_fu_3062_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_49_fu_3208_p2() {
    xor_ln416_49_fu_3208_p2 = (tmp_216_fu_3200_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_50_fu_3346_p2() {
    xor_ln416_50_fu_3346_p2 = (tmp_220_fu_3338_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_51_fu_3484_p2() {
    xor_ln416_51_fu_3484_p2 = (tmp_224_fu_3476_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_52_fu_3622_p2() {
    xor_ln416_52_fu_3622_p2 = (tmp_228_fu_3614_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_53_fu_3760_p2() {
    xor_ln416_53_fu_3760_p2 = (tmp_232_fu_3752_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_54_fu_3898_p2() {
    xor_ln416_54_fu_3898_p2 = (tmp_236_fu_3890_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_55_fu_4036_p2() {
    xor_ln416_55_fu_4036_p2 = (tmp_240_fu_4028_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_56_fu_4174_p2() {
    xor_ln416_56_fu_4174_p2 = (tmp_244_fu_4166_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_57_fu_4312_p2() {
    xor_ln416_57_fu_4312_p2 = (tmp_248_fu_4304_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_58_fu_4450_p2() {
    xor_ln416_58_fu_4450_p2 = (tmp_252_fu_4442_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_59_fu_4588_p2() {
    xor_ln416_59_fu_4588_p2 = (tmp_256_fu_4580_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_60_fu_4726_p2() {
    xor_ln416_60_fu_4726_p2 = (tmp_260_fu_4718_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_61_fu_4864_p2() {
    xor_ln416_61_fu_4864_p2 = (tmp_264_fu_4856_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_62_fu_5002_p2() {
    xor_ln416_62_fu_5002_p2 = (tmp_268_fu_4994_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_63_fu_5140_p2() {
    xor_ln416_63_fu_5140_p2 = (tmp_272_fu_5132_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_64_fu_5278_p2() {
    xor_ln416_64_fu_5278_p2 = (tmp_276_fu_5270_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_65_fu_5416_p2() {
    xor_ln416_65_fu_5416_p2 = (tmp_280_fu_5408_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_66_fu_5554_p2() {
    xor_ln416_66_fu_5554_p2 = (tmp_284_fu_5546_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_67_fu_5692_p2() {
    xor_ln416_67_fu_5692_p2 = (tmp_288_fu_5684_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_68_fu_5830_p2() {
    xor_ln416_68_fu_5830_p2 = (tmp_292_fu_5822_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_69_fu_5968_p2() {
    xor_ln416_69_fu_5968_p2 = (tmp_296_fu_5960_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_70_fu_6106_p2() {
    xor_ln416_70_fu_6106_p2 = (tmp_300_fu_6098_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_71_fu_6244_p2() {
    xor_ln416_71_fu_6244_p2 = (tmp_304_fu_6236_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_72_fu_6382_p2() {
    xor_ln416_72_fu_6382_p2 = (tmp_308_fu_6374_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_73_fu_6520_p2() {
    xor_ln416_73_fu_6520_p2 = (tmp_312_fu_6512_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_74_fu_6658_p2() {
    xor_ln416_74_fu_6658_p2 = (tmp_316_fu_6650_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_75_fu_6796_p2() {
    xor_ln416_75_fu_6796_p2 = (tmp_320_fu_6788_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_76_fu_6934_p2() {
    xor_ln416_76_fu_6934_p2 = (tmp_324_fu_6926_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_77_fu_7072_p2() {
    xor_ln416_77_fu_7072_p2 = (tmp_328_fu_7064_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_78_fu_7210_p2() {
    xor_ln416_78_fu_7210_p2 = (tmp_332_fu_7202_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_79_fu_7348_p2() {
    xor_ln416_79_fu_7348_p2 = (tmp_336_fu_7340_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_80_fu_7486_p2() {
    xor_ln416_80_fu_7486_p2 = (tmp_340_fu_7478_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_81_fu_7624_p2() {
    xor_ln416_81_fu_7624_p2 = (tmp_344_fu_7616_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_82_fu_7762_p2() {
    xor_ln416_82_fu_7762_p2 = (tmp_348_fu_7754_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_83_fu_7900_p2() {
    xor_ln416_83_fu_7900_p2 = (tmp_352_fu_7892_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_84_fu_8038_p2() {
    xor_ln416_84_fu_8038_p2 = (tmp_356_fu_8030_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_85_fu_8176_p2() {
    xor_ln416_85_fu_8176_p2 = (tmp_360_fu_8168_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_86_fu_8314_p2() {
    xor_ln416_86_fu_8314_p2 = (tmp_364_fu_8306_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_87_fu_8452_p2() {
    xor_ln416_87_fu_8452_p2 = (tmp_368_fu_8444_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_fu_586_p2() {
    xor_ln416_fu_586_p2 = (tmp_140_fu_578_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_31_fu_706_p1() {
    zext_ln415_31_fu_706_p1 = esl_zext<6,1>(and_ln415_1_fu_700_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_32_fu_844_p1() {
    zext_ln415_32_fu_844_p1 = esl_zext<6,1>(and_ln415_2_fu_838_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_33_fu_982_p1() {
    zext_ln415_33_fu_982_p1 = esl_zext<6,1>(and_ln415_3_fu_976_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_34_fu_1120_p1() {
    zext_ln415_34_fu_1120_p1 = esl_zext<6,1>(and_ln415_4_fu_1114_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_35_fu_1258_p1() {
    zext_ln415_35_fu_1258_p1 = esl_zext<6,1>(and_ln415_5_fu_1252_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_36_fu_1396_p1() {
    zext_ln415_36_fu_1396_p1 = esl_zext<6,1>(and_ln415_6_fu_1390_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_37_fu_1534_p1() {
    zext_ln415_37_fu_1534_p1 = esl_zext<6,1>(and_ln415_7_fu_1528_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_38_fu_1672_p1() {
    zext_ln415_38_fu_1672_p1 = esl_zext<6,1>(and_ln415_8_fu_1666_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_39_fu_1810_p1() {
    zext_ln415_39_fu_1810_p1 = esl_zext<6,1>(and_ln415_9_fu_1804_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_40_fu_1948_p1() {
    zext_ln415_40_fu_1948_p1 = esl_zext<6,1>(and_ln415_10_fu_1942_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_41_fu_2086_p1() {
    zext_ln415_41_fu_2086_p1 = esl_zext<6,1>(and_ln415_12_fu_2080_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_42_fu_2224_p1() {
    zext_ln415_42_fu_2224_p1 = esl_zext<6,1>(and_ln415_13_fu_2218_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_43_fu_2362_p1() {
    zext_ln415_43_fu_2362_p1 = esl_zext<6,1>(and_ln415_14_fu_2356_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_44_fu_2500_p1() {
    zext_ln415_44_fu_2500_p1 = esl_zext<6,1>(and_ln415_15_fu_2494_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_45_fu_2638_p1() {
    zext_ln415_45_fu_2638_p1 = esl_zext<6,1>(and_ln415_16_fu_2632_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_46_fu_2776_p1() {
    zext_ln415_46_fu_2776_p1 = esl_zext<6,1>(and_ln415_17_fu_2770_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_47_fu_2914_p1() {
    zext_ln415_47_fu_2914_p1 = esl_zext<6,1>(and_ln415_18_fu_2908_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_48_fu_3052_p1() {
    zext_ln415_48_fu_3052_p1 = esl_zext<6,1>(and_ln415_19_fu_3046_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_49_fu_3190_p1() {
    zext_ln415_49_fu_3190_p1 = esl_zext<6,1>(and_ln415_20_fu_3184_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_50_fu_3328_p1() {
    zext_ln415_50_fu_3328_p1 = esl_zext<6,1>(and_ln415_21_fu_3322_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_51_fu_3466_p1() {
    zext_ln415_51_fu_3466_p1 = esl_zext<6,1>(and_ln415_22_fu_3460_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_52_fu_3604_p1() {
    zext_ln415_52_fu_3604_p1 = esl_zext<6,1>(and_ln415_23_fu_3598_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_53_fu_3742_p1() {
    zext_ln415_53_fu_3742_p1 = esl_zext<6,1>(and_ln415_24_fu_3736_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_54_fu_3880_p1() {
    zext_ln415_54_fu_3880_p1 = esl_zext<6,1>(and_ln415_25_fu_3874_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_55_fu_4018_p1() {
    zext_ln415_55_fu_4018_p1 = esl_zext<6,1>(and_ln415_26_fu_4012_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_56_fu_4156_p1() {
    zext_ln415_56_fu_4156_p1 = esl_zext<6,1>(and_ln415_27_fu_4150_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_57_fu_4294_p1() {
    zext_ln415_57_fu_4294_p1 = esl_zext<6,1>(and_ln415_28_fu_4288_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_58_fu_4432_p1() {
    zext_ln415_58_fu_4432_p1 = esl_zext<6,1>(and_ln415_29_fu_4426_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_59_fu_4570_p1() {
    zext_ln415_59_fu_4570_p1 = esl_zext<6,1>(and_ln415_30_fu_4564_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_60_fu_4708_p1() {
    zext_ln415_60_fu_4708_p1 = esl_zext<6,1>(and_ln415_31_fu_4702_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_61_fu_4846_p1() {
    zext_ln415_61_fu_4846_p1 = esl_zext<6,1>(and_ln415_32_fu_4840_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_62_fu_4984_p1() {
    zext_ln415_62_fu_4984_p1 = esl_zext<6,1>(and_ln415_33_fu_4978_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_63_fu_5122_p1() {
    zext_ln415_63_fu_5122_p1 = esl_zext<6,1>(and_ln415_34_fu_5116_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_64_fu_5260_p1() {
    zext_ln415_64_fu_5260_p1 = esl_zext<6,1>(and_ln415_35_fu_5254_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_65_fu_5398_p1() {
    zext_ln415_65_fu_5398_p1 = esl_zext<6,1>(and_ln415_36_fu_5392_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_66_fu_5536_p1() {
    zext_ln415_66_fu_5536_p1 = esl_zext<6,1>(and_ln415_37_fu_5530_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_67_fu_5674_p1() {
    zext_ln415_67_fu_5674_p1 = esl_zext<6,1>(and_ln415_38_fu_5668_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_68_fu_5812_p1() {
    zext_ln415_68_fu_5812_p1 = esl_zext<6,1>(and_ln415_39_fu_5806_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_69_fu_5950_p1() {
    zext_ln415_69_fu_5950_p1 = esl_zext<6,1>(and_ln415_40_fu_5944_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_70_fu_6088_p1() {
    zext_ln415_70_fu_6088_p1 = esl_zext<6,1>(and_ln415_41_fu_6082_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_71_fu_6226_p1() {
    zext_ln415_71_fu_6226_p1 = esl_zext<6,1>(and_ln415_42_fu_6220_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_72_fu_6364_p1() {
    zext_ln415_72_fu_6364_p1 = esl_zext<6,1>(and_ln415_43_fu_6358_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_73_fu_6502_p1() {
    zext_ln415_73_fu_6502_p1 = esl_zext<6,1>(and_ln415_44_fu_6496_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_74_fu_6640_p1() {
    zext_ln415_74_fu_6640_p1 = esl_zext<6,1>(and_ln415_45_fu_6634_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_75_fu_6778_p1() {
    zext_ln415_75_fu_6778_p1 = esl_zext<6,1>(and_ln415_46_fu_6772_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_76_fu_6916_p1() {
    zext_ln415_76_fu_6916_p1 = esl_zext<6,1>(and_ln415_47_fu_6910_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_77_fu_7054_p1() {
    zext_ln415_77_fu_7054_p1 = esl_zext<6,1>(and_ln415_48_fu_7048_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_78_fu_7192_p1() {
    zext_ln415_78_fu_7192_p1 = esl_zext<6,1>(and_ln415_49_fu_7186_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_79_fu_7330_p1() {
    zext_ln415_79_fu_7330_p1 = esl_zext<6,1>(and_ln415_50_fu_7324_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_80_fu_7468_p1() {
    zext_ln415_80_fu_7468_p1 = esl_zext<6,1>(and_ln415_51_fu_7462_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_81_fu_7606_p1() {
    zext_ln415_81_fu_7606_p1 = esl_zext<6,1>(and_ln415_52_fu_7600_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_82_fu_7744_p1() {
    zext_ln415_82_fu_7744_p1 = esl_zext<6,1>(and_ln415_53_fu_7738_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_83_fu_7882_p1() {
    zext_ln415_83_fu_7882_p1 = esl_zext<6,1>(and_ln415_54_fu_7876_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_84_fu_8020_p1() {
    zext_ln415_84_fu_8020_p1 = esl_zext<6,1>(and_ln415_55_fu_8014_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_85_fu_8158_p1() {
    zext_ln415_85_fu_8158_p1 = esl_zext<6,1>(and_ln415_56_fu_8152_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_86_fu_8296_p1() {
    zext_ln415_86_fu_8296_p1 = esl_zext<6,1>(and_ln415_57_fu_8290_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_87_fu_8434_p1() {
    zext_ln415_87_fu_8434_p1 = esl_zext<6,1>(and_ln415_58_fu_8428_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_fu_568_p1() {
    zext_ln415_fu_568_p1 = esl_zext<6,1>(and_ln415_fu_562_p2.read());
}

}

