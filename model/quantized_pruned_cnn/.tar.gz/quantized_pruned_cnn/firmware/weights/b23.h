//Numpy array shape [10]
//Min -0.064166076481
//Max 0.128310143948
//Number of zeros 0

#ifndef B23_H_
#define B23_H_

#ifndef __SYNTHESIS__
output_dense_bias_t b23[10];
#else
output_dense_bias_t b23[10] = {-0.0218051784, -0.0421033241, -0.0010082105, -0.0027705859, -0.0308485907, 0.0216933452, 0.0959744155, -0.0641660765, 0.1283101439, -0.0098417522};
#endif

#endif
