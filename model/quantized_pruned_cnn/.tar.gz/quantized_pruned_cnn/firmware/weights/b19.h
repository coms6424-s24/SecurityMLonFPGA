//Numpy array shape [64]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 64

#ifndef B19_H_
#define B19_H_

#ifndef __SYNTHESIS__
bias19_t b19[64];
#else
bias19_t b19[64] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
#endif

#endif
